# Brand kit da Asa Locadora — v02 (21/10/2026; avatar e tokens revistos no mesmo dia, R02 e R09)

Kit de marca da **Asa Locadora** (o logo usa o lettering ASA RENT A CAR). Segue as **Diretrizes de Marca e Sistema de Design v3.3**, de 21/10/2026 (`02_MARCA-E-IDENTIDADE/plataforma-de-marca/2026-10-21_diretrizes-de-marca-v3-3_v01.pdf`). Em caso de dúvida, vale o que está nas diretrizes.

Pacote para enviar a agências e fornecedores: `2026-10-21_brand-kit-completo-asa_v02.zip`, na pasta acima desta.

## O que tem

| Pasta | Conteúdo |
| :--- | :--- |
| `logos/svg/` | 9 vetores: 4 lockups horizontais (fundo claro, fundo escuro, monocromático branco, monocromático preto), `logo-asa-horizontal-sobre-amarelo`, 3 símbolos (vermelho, branco, preto) e `avatar-asa-perfil` |
| `logos/png/` | Cada SVG em PNG com fundo transparente. Lockups: 512 px de altura e 1600 px de largura. Símbolos e avatar: 1024×1024 e 512×512. Mais uma prévia do logo sobre amarelo com o fundo pintado (`…_previa-fundo-amarelo.png`), só para conferir |
| `cores-e-tokens/` | `asa-tokens_v02.json` (tokens de design), `tabela-equivalencias-cores-asa_v02.md` (Hex, RGB, CMYK e Pantone) e `Asa-Locadora-v3.2.ase` (amostras para Adobe) |
| `fontes/` | BR Omny em 5 faces OTF (Regular 400, Medium 500, Bold 700, Black 900 e Black Italic 900) e `br-omny.css` |
| `icones/` | Feather com traço de 1,5 px: 287 ícones em `svg-1.5px/`, os 20 mais usados em `core-20-icones/`, o sprite e o pacote zip |
| `templates-grid/` | Guias de corte a 8° para 16:9, 1:1, 4:5 e 9:16 (SVG) e o pacote zip. São guias de composição, não peças prontas |

## Qual logo usar

A regra é sempre a **assinatura completa** (símbolo + ASA RENT A CAR).

| Fundo | Arquivo | Como fica |
| :--- | :--- | :--- |
| Branco ou Cinza Mist | `logo-asa-horizontal-fundo-claro` | Símbolo vermelho, lettering preto |
| Amarelo Asa (#FEC42B) | `logo-asa-horizontal-sobre-amarelo` | Versão colorida: símbolo vermelho, lettering preto (decisão D19). O símbolo vermelho sobre amarelo mede 2,94:1, abaixo de 3:1; é uma **exceção de marca registrada, só para o logo**. Texto vermelho sobre amarelo continua proibido |
| Preto Asa ou Preto Profundo | `logo-asa-horizontal-fundo-escuro` | Símbolo vermelho, lettering branco |
| Vermelho Asa (#E80911) | `logo-asa-horizontal-monocromatico-branco` | Tudo em branco |
| Impressão em uma cor | `logo-asa-horizontal-monocromatico-preto` | Tudo em preto. Não é mais a versão para fundo amarelo |

**Símbolo sozinho** (`simbolo-asa-*`): só em dois casos.
1. Marca d'água a **13% de opacidade** sobre fundo amarelo, no máximo uma vez por peça.
2. Dentro do ícone de perfil. Para redes sociais, WhatsApp e perfil do Google, use o arquivo pronto `avatar-asa-perfil`: **círculo Vermelho Asa (#E80911) com o símbolo da asa em branco**, a 66% da largura, centrado (decisão R02). É o mesmo desenho do ícone de perfil do site.

**Respiro e tamanho mínimo** (decisão M17):
- Área livre em volta do logo igual à altura de uma letra "A" do lettering ASA, em todos os lados.
- Mínimo impresso: 2,0 cm de altura do logo completo.
- Mínimo em tela: 24 px de altura do lockup. Abaixo disso, só o símbolo, e apenas nos dois casos acima.

**Nunca:** distorcer, recolorir partes, aplicar sombra ou efeito, redesenhar traços, colocar o logo em fundo que não esteja na tabela acima, ou escrever "Asa Rent a Car" em texto (o nome nos textos é Asa Locadora; "Asa Rent a Car" só em inglês, espanhol e documentos institucionais assinados pela Presidência).

## Cores, fontes e ícones em uma linha cada

- **Cores:** 8 oficiais, com proporção amarelo 40%, preto 25%, vermelho até 20% (só ação), mist 15%. As cores do bloco `extensoes_interface` dos tokens (inclusive o turquesa do Pix e o fundo de campo desabilitado `#F2F2F0`, R09) são só de interface e **nunca** cor de marca em peça. Exceção (R10): o Cinza Texto `#4A4C50` e o `#5A5C60` podem ser texto secundário em documentos (apresentação, assinatura, relatório), nunca fundo ou destaque.
- **Fonte:** só BR Omny, nessas 5 faces. Nenhum texto abaixo de 12 px em tela. A licença da fonte segue como está (decisão M25, risco registrado): não redistribua as OTF fora do trabalho para a Asa.
- **Ícones:** só Feather, contorno de 1,5 px, 24 px no texto e 48 px em destaque. Evite os ícones de marcas de terceiros que vêm no conjunto.

## O que mudou da v01 (setembro/2026)

1. **Novo** `logo-asa-horizontal-sobre-amarelo` (SVG e PNG), com o mesmo desenho do fundo claro (D19, M22).
2. **Novo** `avatar-asa-perfil` (SVG e PNG).
3. **Novos PNGs** de todos os logos, com fundo transparente. A v01 só tinha SVG.
4. Os SVGs agora têm `<title>` e largura e altura próprias (antes era `100%`). O desenho é o mesmo.
5. **Saíram** os wordmarks "ASA" sem símbolo (`wordmark-asa-preto`, `-branco`, `-vermelho`), por decisão M23. Ficam como histórico, fora do kit.
6. Tokens **v02** (`asa-tokens_v02.json`): sem raio "pill"; raios 0, 8 px e 50%; borda de 1,5 px; sem sombra; tipografia, movimento, espaçamento do CSS, espaço entre faixas, regras do logo e o bloco `extensoes_interface` (M15, M26).
7. Tabela de cores com o nome Asa Locadora, funções de Branco e Mist corrigidas e as extensões de interface numa seção separada.
8. Fontes, `.ase`, ícones e guias de 8° iguais aos da v01.
9. O kit não leva mais arquivos de outras áreas (planilhas, relatórios e exports que estavam soltos na pasta da v01).
10. **Avatar refeito (R02, 21/10/2026):** `avatar-asa-perfil` agora é círculo Vermelho Asa com a asa branca (antes: círculo amarelo com a asa vermelha). SVG e PNG 1024/512 substituídos; os antigos estão em `logos/svg/_versoes-anteriores/` e `logos/png/_versoes-anteriores/` e **não devem ser usados**.
11. **Tokens (R09, R10):** `extensoes_interface` ganhou `pix`, `pixBg` e `disabledBg`; a tabela de cores ganhou as mesmas linhas e a exceção do Cinza Texto em documentos. As versões anteriores estão em `cores-e-tokens/_versoes-anteriores/`.

## Limitações conhecidas

- **Não há vetor para gráfica em CMYK/Pantone** (PDF ou EPS). Os SVGs são RGB. Para impressão, peça à gráfica a conversão com os valores CMYK e Pantone da tabela e faça prova de cor do amarelo.
- O `.ase` traz amostras só em RGB.

Origem dos arquivos: pasta mestre `02_MARCA-E-IDENTIDADE/design-system/2026-10_design-system-offline/assets/downloads/` (decisão M27).
